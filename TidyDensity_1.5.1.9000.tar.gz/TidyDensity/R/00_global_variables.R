globalVariables(
  names = c(
    "d", "density", "dx", "dy", "p", "sd", "sim_number", "x", "y",
    ".n", ".num_sims", "dist_name", "random_walk_value", "results",
    "dist_type", "var", "shape", "rec_no", "value", "Empirical", "bootstrap_samples",
    "cmy", "lambda", "location", "m", "max_est", "mean_log", "method", "min_est",
    "name", "prob", "rate", "sd_log", "shape1", "shape2", "size", "total", "total_deviance",
    "abs_aic", "aic_value", "data", "dist_with_params", "ks", "lm", "lm_model", "mu",
    "stan_dev", "tidy_ks", "prop", "dens_tbl", "cih", "cil", "mstat", "stat", ".",
    "variable",".N",".cum_stat",".return_tibble",".sample","dof","ncp"
  )
)
